# Sample Code Repository

This repository contains sample Python and Bash scripts with intentional vulnerabilities for educational purposes.